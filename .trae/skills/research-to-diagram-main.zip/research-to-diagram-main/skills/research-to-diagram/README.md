# Research to Diagram - 使用指南

从研究到可视化的一站式知识图谱生成工具。

## 快速开始

### 1. 安装依赖

```bash
# macOS
brew install graphviz

# Ubuntu/Debian
sudo apt-get install graphviz

# 验证安装
dot -V
```

### 2. 使用 Skill

直接向 Claude Code 描述你的研究需求：

```bash
# 示例 1：文学作品人物关系
"深度调查《红楼梦》里人物之间的关系，然后做个结构图 PDF"

# 示例 2：技术架构研究
"研究 Kubernetes 的架构并生成可视化图谱"

# 示例 3：历史事件分析
"分析春秋战国时期各国关系，做成关系图"
```

## 工作流程

```
用户输入主题
    ↓
WebSearch 深度调研
    ↓
信息提取与整理
    ↓
结构设计
    ↓
生成 Graphviz DOT
    ↓
编译为 PDF
    ↓
提供下载链接和参考资料
```

## 模板示例

### 人物关系图

适用场景：
- 文学作品人物分析
- 历史人物关系
- 家族谱系
- 组织人员结构

参考模板：`examples/character_relationships.dot`

特点：
- 使用 `cluster` 分组家族/团体
- 不同颜色区分类别
- 红色实线表示婚姻，黑色表示血缘
- 虚线表示其他关系

### 概念图谱

适用场景：
- 知识体系梳理
- 学科分类
- 概念关系分析
- 思维导图

参考模板：`examples/concept_map.dot`

特点：
- 树状层次结构
- 核心概念在顶部
- 颜色编码不同类别
- 虚线表示关联关系

### 技术架构图

适用场景：
- 系统架构设计
- 微服务架构
- 技术栈可视化
- 组件依赖关系

参考模板：`examples/tech_architecture.dot`

特点：
- 分层架构（客户端/网关/应用/数据）
- 不同形状表示不同组件类型
- 实线=同步调用，虚线=异步
- 包含图例说明

## 手动生成 PDF

如果你有 `.dot` 文件，可以使用提供的脚本生成 PDF：

```bash
# 使用脚本
bash ~/.claude/skills/research-to-diagram/scripts/generate_pdf.sh input.dot output.pdf

# 或直接使用 dot 命令
dot -Tpdf input.dot -o output.pdf

# 生成其他格式
dot -Tpng input.dot -o output.png  # PNG 图片
dot -Tsvg input.dot -o output.svg  # SVG 矢量图
```

## Graphviz 常用配置

### 布局方向

```dot
graph [rankdir=TB]  // 上到下
graph [rankdir=LR]  // 左到右
graph [rankdir=BT]  // 下到上
graph [rankdir=RL]  // 右到左
```

### 节点形状

```dot
node [shape=box]        // 矩形
node [shape=ellipse]    // 椭圆
node [shape=circle]     // 圆形
node [shape=diamond]    // 菱形
node [shape=cylinder]   // 柱状（数据库）
node [shape=component]  // 组件
```

### 边的样式

```dot
edge [style=solid]      // 实线
edge [style=dashed]     // 虚线
edge [style=dotted]     // 点线
edge [style=bold]       // 粗线
edge [arrowsize=0.8]    // 箭头大小
```

### 中文支持

```dot
graph [fontname="Arial Unicode MS"]
node [fontname="Arial Unicode MS"]
edge [fontname="Arial Unicode MS"]

// 或使用系统字体
graph [fontname="STHeiti"]  // macOS 黑体
graph [fontname="SimHei"]   // Windows 黑体
```

### 颜色方案

常用颜色：
- `#ffd700` - 金色（重要）
- `#ff6347` - 番茄红（主要）
- `#87ceeb` - 天蓝色（次要）
- `#98fb98` - 淡绿色（辅助）
- `#ffb6c1` - 粉红（特殊）

颜色命名：
- `red`, `blue`, `green`, `yellow`, `purple`, `orange`
- `lightgrey`, `lightblue`, `lightgreen`

## 高级技巧

### 1. 强制节点同层

```dot
{rank=same; node1; node2; node3}
```

### 2. 隐藏边（控制布局）

```dot
node1 -> node2 [style=invis]
```

### 3. 合并相同边

```dot
graph [concentrate=true]
```

### 4. 调整间距

```dot
graph [
    nodesep=1.0    // 节点水平间距
    ranksep=1.5    // 层级垂直间距
]
```

### 5. 跨 cluster 连接

```dot
graph [compound=true]
node1 -> node2 [ltail=cluster_a lhead=cluster_b]
```

## 常见问题

### Q: 中文显示为乱码或方框

A: 确保设置了中文字体：

```dot
graph [fontname="Arial Unicode MS"]
node [fontname="Arial Unicode MS"]
edge [fontname="Arial Unicode MS"]
```

### Q: 图谱太复杂，布局混乱

A:
1. 使用 `concentrate=true` 合并边
2. 调整 `nodesep` 和 `ranksep` 增大间距
3. 分割成多个子图
4. 使用 `rank=same` 控制布局

### Q: 边的标签重叠

A:
1. 减少标签长度
2. 使用 `labeldistance` 和 `labelangle` 调整位置
3. 改用 `xlabel` 代替 `label`

### Q: PDF 文件太大

A:
1. 使用 SVG 格式：`dot -Tsvg input.dot -o output.svg`
2. 减少节点数量，提高抽象层次
3. 分割成多个图表

### Q: 想要水平布局

A: 将 `rankdir=TB` 改为 `rankdir=LR`

## 参考资源

- [Graphviz 官方文档](https://graphviz.org/documentation/)
- [DOT 语言指南](https://graphviz.org/doc/info/lang.html)
- [节点形状参考](https://graphviz.org/doc/info/shapes.html)
- [颜色名称列表](https://graphviz.org/doc/info/colors.html)

## 与 structure-to-pdf 的对比

| 特性 | research-to-diagram | structure-to-pdf |
|------|---------------------|------------------|
| **数据来源** | 自动调研收集 | 用户提供 |
| **适用场景** | 探索性研究 | 快速转换 |
| **调研能力** | ✅ WebSearch | ❌ |
| **知识整理** | ✅ 自动提取 | ❌ |
| **工作量** | 全自动 | 需准备数据 |
| **时间** | 较长（2-5分钟） | 快速（<1分钟） |
| **参考资料** | ✅ 提供来源 | ❌ |
| **适合主题** | 复杂知识体系 | 简单结构数据 |

**选择建议**：
- 📚 **研究型任务** → 使用 `research-to-diagram`
- 🔄 **转换型任务** → 使用 `structure-to-pdf`

## 示例项目

### 1. 红楼梦人物关系图

**输入**：
```
深度调查《红楼梦》里人物之间的关系，然后做个结构图 PDF
```

**输出**：
- `hongloumeng_relations.dot` - 源文件
- `hongloumeng_relations.pdf` - 152KB PDF
- 包含四大家族、金陵十二钗、宝黛钗三角关系

**特色**：
- 7个 subgraph cluster 分组
- 50+ 人物节点
- 多种关系类型（血缘、婚姻、联姻）
- 完整图例说明

### 2. Kubernetes 架构图

**输入**：
```
研究 Kubernetes 架构并生成可视化图谱
```

**可能输出**：
- 控制平面组件（API Server, Scheduler, Controller Manager）
- 数据平面组件（Kubelet, Kube-proxy）
- 插件生态（CNI, CSI, CRI）
- 组件间通信关系

### 3. 三国人物关系

**输入**：
```
分析《三国演义》主要人物关系，生成关系图
```

**可能输出**：
- 魏蜀吴三大阵营
- 君臣关系、兄弟关系、联盟关系
- 重要战役节点
- 人物命运走向

## 版本历史

- **v1.0** (2026-01-02)
  - 初始发布
  - 基于红楼梦人物关系图项目经验
  - 支持 Graphviz/DOT 自动生成
  - 集成 WebSearch 深度调研
  - 提供三种模板（人物/概念/技术）

## 贡献

欢迎提交：
- 新的图谱模板
- 最佳实践案例
- Bug 报告
- 功能建议

## 许可证

MIT License
